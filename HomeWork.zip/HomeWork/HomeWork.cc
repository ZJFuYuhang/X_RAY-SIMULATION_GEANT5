#include "G4RunManager.hh"
#include "G4UImanager.hh"


#include "G4VisManager.hh"
#include "G4VisExecutive.hh"
#include "G4UItcsh.hh"
#include "G4UIterminal.hh"
#include "G4UIsession.hh"

#include "HWDetectorConstruction.hh"
#include "HWPhysicsList.hh"
#include "HWPrimaryGeneratorAction.hh"

int main(int argc, char** argv)
{
    G4RunManager* runManager = new G4RunManager;

    G4VisManager* visManager = new G4VisExecutive;
    visManager->Initialize();

    runManager->SetUserInitialization(new HWDetectorConstruction());
    runManager->SetUserInitialization(new HWPhysicsList());
    runManager->SetUserAction(new HWPrimaryGeneratorAction());
    runManager->Initialize();

    G4UIsession* session = new G4UIterminal(new G4UItcsh());

    G4UImanager* UI = G4UImanager::GetUIpointer();
    if(argc==1)
    {	UI->ApplyCommand("/run/verbose 2");
        G4String command="/control/execute init_vis.mac";
        UI->ApplyCommand(command);
        session->SessionStart();
    }
    else
    {	UI->ApplyCommand("/run/verbose 2");
        G4String command="/control/execute ";
        G4String fileName = argv[1];
        UI->ApplyCommand(command+fileName);
        session->SessionStart();
    }

    G4int numberOfEvent = 3;
    runManager->BeamOn(numberOfEvent);

    delete session;
    delete visManager;
    delete runManager;
    return 0;


}
