#include "HWPrimaryGeneratorAction.hh"

#include "G4Event.hh"
#include "G4ParticleGun.hh"
#include "G4ParticleTable.hh"
#include "G4SystemOfUnits.hh"
#include "G4ParticleDefinition.hh"
#include "globals.hh"
#include "G4SystemOfUnits.hh"

HWPrimaryGeneratorAction::HWPrimaryGeneratorAction()
{
    G4int nofParticles = 1;
    fParticleGun  = new G4ParticleGun(nofParticles);

    G4ParticleTable* particleTable = G4ParticleTable::GetParticleTable();
    G4ParticleDefinition* particle= particleTable->FindParticle("e-");
    fParticleGun->SetParticleDefinition(particle);
    //fParticleGun->SetParticleTime(0.0*ns);
    fParticleGun->SetParticlePosition(G4ThreeVector(0.0,0.0,2.*mm));
    fParticleGun->SetParticleMomentumDirection(G4ThreeVector(0,0,-1));
    fParticleGun->SetParticleEnergy(300.0*keV);//在这里等效认为电子能量等于管电压

}



HWPrimaryGeneratorAction::~HWPrimaryGeneratorAction()
{
    //dtor
    delete fParticleGun;
}
void HWPrimaryGeneratorAction::GeneratePrimaries(G4Event* anEvent)
{
    fParticleGun->GeneratePrimaryVertex(anEvent);
}
