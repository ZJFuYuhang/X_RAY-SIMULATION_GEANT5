#include "HWPhysicsList.hh"
#include "G4ParticleTypes.hh"

#include "G4SystemOfUnits.hh"
#include "G4BosonConstructor.hh"
#include "G4LeptonConstructor.hh"
#include "G4MesonConstructor.hh"
#include "G4BaryonConstructor.hh"
#include "G4IonConstructor.hh"


#include "G4EmPenelopePhysics.hh"
#include "G4VPhysicsConstructor.hh"

#include "G4ProcessManager.hh"
#include "G4eBremsstrahlung.hh"
#include "G4eIonisation.hh"
#include "G4eMultipleScattering.hh"
#include "G4PhotoElectricEffect.hh"
#include "G4ComptonScattering.hh"

#include "G4ProductionCuts.hh"
#include "G4Region.hh"
#include "G4RegionStore.hh"

HWPhysicsList::HWPhysicsList() : G4VUserPhysicsList()
{
    //ctor
}

HWPhysicsList::~HWPhysicsList()
{
    //dtor
}
void HWPhysicsList::ConstructParticle()
{
    G4BosonConstructor bConstructor;
    bConstructor.ConstructParticle();

    G4LeptonConstructor lConstructor;
    lConstructor.ConstructParticle();

    G4MesonConstructor mConstructor;
    mConstructor.ConstructParticle();

    G4BaryonConstructor rConstructor;
    rConstructor.ConstructParticle();

    G4IonConstructor iConstructor;
    iConstructor.ConstructParticle();
    //    //由于各种物理过程涉及不同例子，故只声明你需要的粒子是不够的
    //    G4Electron::ElectronDefinition();
    //    G4OpticalPhoton::OpticalPhotonDefinition();
}

void HWPhysicsList::ConstructProcess()
{
    AddTransportation();
    //论文推荐模型
    G4VPhysicsConstructor* emPhysicsList = new G4EmPenelopePhysics();
    emPhysicsList->ConstructProcess();
    //    auto theParticleIterator=GetParticleIterator();
    //    theParticleIterator->reset();
    //    while( (*theParticleIterator)() )
    //    {
    //        G4ParticleDefinition* particle = theParticleIterator->value();
    //        G4ProcessManager* pmanager = particle->GetProcessManager();
    //        G4String particleName = particle->GetParticleName();
    //        if(particleName == "e-"){
    //            //韧致辐射
    //            pmanager->AddDiscreteProcess(new G4eBremsstrahlung());
    //            //电离
    //            pmanager->AddDiscreteProcess(new G4eIonisation());
    //            //多重散射
    //            pmanager->AddDiscreteProcess(new G4eMultipleScattering());
    //
    //        }
    //        else if (particleName == "opticalphoton")
    //        {
    //            //光电效应
    //            pmanager->AddDiscreteProcess(new G4PhotoElectricEffect());
    //            //康普顿散射
    //            pmanager->AddDiscreteProcess(new G4ComptonScattering());
    //        }
    //    }
}
void HWPhysicsList::SetCuts()
{
    //SetDefaultCutValue();
    SetCutsWithDefault();
    SetCutValue(500*nm,"e-");
    SetCutValue(3000*nm,"gamma");
//    G4Region* region;
//    G4ProductionCuts* cuts;
//    G4String regName;
//    regName = "world";//不知道world的名字
//    region = G4RegionStore::GetInstance()->GetRegion(regName);
//    cuts = new G4ProductionCuts;
//    cuts->SetProductionCut(3000.0*nm,G4ProductionCuts::GetIndex("gamma"));
//    cuts->SetProductionCut(500.0*nm,G4ProductionCuts::GetIndex("e-"));
//    region->SetProductionCuts(cuts);
//    G4Region* region;
//    G4ProductionCuts* cuts;
//    G4String regName;
//    regName = "world";//不知道world的名字
//    region = G4RegionStore::GetInstance()->GetRegion(regName);
//    cuts = new G4ProductionCuts;
//    cuts->SetProductionCut(3000.0*nm,G4ProductionCuts::GetIndex("gamma"));
//    cuts->SetProductionCut(500.0*nm,G4ProductionCuts::GetIndex("e-"));
//    region->SetProductionCuts(cuts);
}
