#include "HWDetectorConstruction.hh"

#include "G4Material.hh"
#include "G4Box.hh"
#include "G4CutTubs.hh"
#include "G4Tubs.hh"
#include "G4NistManager.hh"
#include "globals.hh"
#include "G4LogicalVolume.hh"
#include "G4ThreeVector.hh"
#include "G4PVPlacement.hh"
#include "G4SystemOfUnits.hh"

HWDetectorConstruction::HWDetectorConstruction() :
    worldLog(0),blgLog(0),zkgLog(0),lgaiLog(0),rgaiLog(0),baLog(0),lbpLog(0),bpLog(0),
    worldPhys(0),blgPhys(0),zkgPhys(0),lgaiPhys(0),rgaiPhys(0),baPhys(0),lbpPhys(0),bpPhys(0)
{
}

HWDetectorConstruction::~HWDetectorConstruction()
{
    //dtor
}
G4VPhysicalVolume* HWDetectorConstruction::Construct()
{
    G4NistManager* man = G4NistManager::Instance();
    //用于声明材料
    G4double a;
    G4double z;
    G4double density;
//世界定义
    //实体定义
    G4double world_hx = 2.0*m;
    G4double world_hy = 2.0*m;
    G4double world_hz = 2.0*m;
    G4Box* worldBox = new G4Box("world",world_hx,world_hy,world_hz);
    //逻辑体定义
    G4Material* Air = man->FindOrBuildMaterial("G4_AIR");
    worldLog = new G4LogicalVolume(worldBox,Air,"world",0,0,0);
    //物理体定义
    worldPhys= new G4PVPlacement(0,
                                 G4ThreeVector(),
                                 worldLog,
                                 "world",
                                 0,
                                 false,
                                 0);
//外边包铅的玻璃管
    //实体定义
    G4double blg_innerRadius = 0.9*cm;
    G4double blg_outerRadius = 1.5*cm;
    G4double blg_hz = 3.*cm;
    G4double blg_startAngle = 45.*deg;
    G4double blg_spanningAngle = 315.*deg;
    G4Tubs* blgTube = new G4Tubs("blg",blg_innerRadius,blg_outerRadius,blg_hz,blg_startAngle,blg_spanningAngle);
    //逻辑体
    //G4Material* Pb = new G4Material("Lead", z= 82., a= 207.19*g/mole, density= 11.35*g/cm3);
    G4Material* Pb = man->FindOrBuildMaterial("G4_Pb");
    blgLog = new G4LogicalVolume(blgTube,Pb,"blg");
    //物理体
    blgPhys= new G4PVPlacement(0,
                               G4ThreeVector(0,0,0),
                               blgLog,
                               "blg",
                               worldLog,
                               false,
                               0);
//两个铅盖
    //实体定义
    G4double lgai_innerRadius = 0*cm;
    G4double lgai_outerRadius = 1.5*cm;
    G4double lgai_hz = 10*mm;
    G4double lgai_startAngle = 0.0*deg;
    G4double lgai_spanningAngle = 360.0*deg;
    G4Tubs* lgaiTube = new G4Tubs("lgai",lgai_innerRadius,lgai_outerRadius,lgai_hz,lgai_startAngle,lgai_spanningAngle);
    //逻辑体
    lgaiLog = new G4LogicalVolume(lgaiTube,Pb,"lgai");
    //物理体
    lgaiPhys = new G4PVPlacement(0,
                                 G4ThreeVector(0.0*cm,0.0*cm,4.*cm),
                                 lgaiLog,
                                 "lgai",
                                 worldLog,
                                 false,
                                 0);
    G4double rgai_innerRadius = 0*cm;
    G4double rgai_outerRadius = 1.5*cm;
    G4double rgai_hz = 10*mm;
    G4double rgai_startAngle = 0.0*deg;
    G4double rgai_spanningAngle = 360.0*deg;
    G4Tubs* rgaiTube = new G4Tubs("rgai",rgai_innerRadius,rgai_outerRadius,rgai_hz,rgai_startAngle,rgai_spanningAngle);
    //逻辑体
    rgaiLog = new G4LogicalVolume(rgaiTube,Pb,"rgai");
    //物理体
    rgaiPhys= new G4PVPlacement(0,
                                G4ThreeVector(0.0*cm,0.0*cm,-4.*cm),
                                rgaiLog,
                                "rgais",
                                worldLog,
                                false,
                                0);
//真空圆柱体区域
    //实体定义
    G4double zkg_innerRadius = 0*cm;
    G4double zkg_outerRadius = 0.9*cm;
    G4double zkg_hz = 3.*cm;
    G4double zkg_startAngle = 0.0*deg;
    G4double zkg_spanningAngle = 360.0*deg;
    G4Tubs* zkgTube = new G4Tubs("zkg",zkg_innerRadius,zkg_outerRadius,zkg_hz,zkg_startAngle,zkg_spanningAngle);
    //逻辑体
    //G4Material* Vacuum = man->FindOrBuildMaterial("G4_Galactic");
    G4Material* Vacuum =new G4Material("Galactic", z=1., a=1.01*g/mole,density= 1.e-25*g/cm3, kStateGas, 2.73*kelvin, 3.e-18*pascal);
    zkgLog = new G4LogicalVolume(zkgTube,Vacuum,"zkg");
    //物理体
    zkgPhys= new G4PVPlacement(0,
                               G4ThreeVector(0,0,0),
                               zkgLog,
                               "zkg",
                               worldLog,
                               false,
                               0);
//靶子
    //实体
    G4double ba_innerRadius = 0.*cm;
    G4double ba_outerRadius = 0.5*cm;
    G4double ba_hz = 0.1*cm;
    G4double ba_startAngle = 0.*deg;
    G4double ba_spanningAngle = 360.*deg;
    ////圆柱形切割段或切割管参数无法解读
    //G4CutTubs* baTube = new G4CutTubs("Ba",ba_innerRadius,ba_outerRadius,ba_hz,ba_startAngle,ba_spanningAngle,G4ThreeVector(0,0,0),G4ThreeVector(0.2*cm,0.,0.16*cm));
    G4Tubs* baTube = new G4Tubs("Ba",ba_innerRadius,ba_outerRadius,ba_hz,ba_startAngle,ba_spanningAngle);
    //逻辑体
    G4Material* W = new G4Material("Tungsten", z= 74., a= 183.84*g/mole, density= 19.35*g/cm3);
    //G4Material* W = man->FindOrBuildMaterial("G4_W");
    baLog = new G4LogicalVolume(baTube,W,"Ba");
    //物理体
    G4double ba_x = 0.*cm;
    G4double ba_y = 0.*cm;
    G4double ba_z = -2*mm;
    G4RotationMatrix* ba_rotm  = new G4RotationMatrix();
    //ba_rotm->rotateY(0.*deg);
    ba_rotm->rotateY(-22.*deg);
    baPhys= new G4PVPlacement(ba_rotm,
                              G4ThreeVector(ba_x,ba_y,ba_z),
                              baLog,
                              "Ba",
                              zkgLog,
                              false,
                              0);
//Be滤波片(bp)
    //实体
    G4double bp_hx = 10.0*cm;
    G4double bp_hy = 10.0*cm;
    G4double bp_hz = 2.2*mm;
    G4Box* bpBox = new G4Box("bp",bp_hx,bp_hy,bp_hz);
    //逻辑体定义
    G4Material* Be = man->FindOrBuildMaterial("G4_Be");
    bpLog = new G4LogicalVolume(bpBox,Be,"bp");
    //物理体定义
    G4double bp_x = 10.*cm;
    G4double bp_y = 0.*cm;
    G4double bp_z = 0.*cm;
    G4RotationMatrix* bp_rotm  = new G4RotationMatrix();
    bp_rotm->rotateY(90.*deg);
    bpPhys= new G4PVPlacement(bp_rotm,
                              G4ThreeVector(bp_x,bp_y,bp_z),
                              bpLog,
                              "bp",
                              worldLog,
                              false,
                              0);
//AL滤波片
    //实体
    G4double lbp_hx = 10.0*cm;
    G4double lbp_hy = 10.0*cm;
    G4double lbp_hz = 2.5*mm;
    G4Box* lbpBox = new G4Box("lbp",lbp_hx,lbp_hy,lbp_hz);
    //逻辑体定义
    //G4Material* Pt = new G4Material("Platinum", z= 74., a= 195.078*g/mole, density= 21.45*g/cm3);
    G4Material* Pt = man->FindOrBuildMaterial("G4_Pt");
    lbpLog = new G4LogicalVolume(lbpBox,Pt,"lbp");
    //物理体定义
    G4double lbp_x = 12.*cm;
    G4double lbp_y = 0.*cm;
    G4double lbp_z = 0.*cm;
    G4RotationMatrix* lbp_rotm  = new G4RotationMatrix();
    lbp_rotm->rotateY(90.*deg);
    lbpPhys= new G4PVPlacement(lbp_rotm,
                               G4ThreeVector(lbp_x,lbp_y,lbp_z),
                               lbpLog,
                               "lbp",
                               worldLog,
                               false,
                               0);
    return worldPhys;
}
