#ifndef HWPRIMARYGENERATORACTION_H
#define HWPRIMARYGENERATORACTION_H

#include "G4VUserPrimaryGeneratorAction.hh"

class G4ParticleGun;
class G4Event;

class HWPrimaryGeneratorAction : public G4VUserPrimaryGeneratorAction
{
public:
    HWPrimaryGeneratorAction();
    virtual ~HWPrimaryGeneratorAction();
public:
    void GeneratePrimaries(G4Event*);
protected:

private:
    G4ParticleGun*  fParticleGun;
};

#endif // HWPRIMARYGENERATORACTION_H
