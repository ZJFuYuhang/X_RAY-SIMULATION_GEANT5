#ifndef HWPHYSICSLIST_H
#define HWPHYSICSLIST_H

#include "G4VUserPhysicsList.hh"

class G4LogicalVolume;
class G4VPhysicalVolume;
class HWPhysicsList : public G4VUserPhysicsList
{
    public:
        HWPhysicsList();
        virtual ~HWPhysicsList();
    public:
        virtual void ConstructParticle();
        virtual void ConstructProcess();
        virtual void SetCuts();

    protected:

    private:
};

#endif // HWPHYSICSLIST_H
