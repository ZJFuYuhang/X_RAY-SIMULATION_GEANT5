#ifndef HWDETECTORCONSTRUCTION_H
#define HWDETECTORCONSTRUCTION_H

#include "G4VUserDetectorConstruction.hh"

class HWDetectorConstruction : public G4VUserDetectorConstruction
{
public:
    HWDetectorConstruction();
    virtual ~HWDetectorConstruction();
public:
    virtual G4VPhysicalVolume* Construct();
protected:

private:
    // Logical volumes
    G4LogicalVolume* worldLog;
    G4LogicalVolume* blgLog;
    G4LogicalVolume* zkgLog;
    G4LogicalVolume* lgaiLog;
    G4LogicalVolume* rgaiLog;
    G4LogicalVolume* baLog;
    G4LogicalVolume* lbpLog;
    G4LogicalVolume* bpLog;
    // Physical volumes
    G4VPhysicalVolume* worldPhys;
    G4VPhysicalVolume* blgPhys;
    G4VPhysicalVolume* zkgPhys;
    G4VPhysicalVolume* lgaiPhys;
    G4VPhysicalVolume* rgaiPhys;
    G4VPhysicalVolume* baPhys;
    G4VPhysicalVolume* lbpPhys;
    G4VPhysicalVolume* bpPhys;

};

#endif // HKDETECTORCONSTRUCTION_H
